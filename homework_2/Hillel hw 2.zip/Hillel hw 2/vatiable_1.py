a = int(input('a: '))
b = int(input('b: '))

var = a
a = b
b = var

print('a =', a)
print('b =', b)